package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import main.Algorithm;

public class AlgorithmTest {

	public final float floatTolerance = 0.0001f;
	private Algorithm alg;
	
	@Before
	public void SetUp() {
		this.alg =  new Algorithm();
	}

	/**
	 * Test gcd function
	 */
	@Test
	public void TestGCD() {

	}

	/**
	 * Test min function
	 */
	@Test
	public void TestMin() {

	}

	/**
	 * Test numZero function
	 */
	@Test
	public void TestNumZero() {

	}
	
	/**
	 * Test negateArray function
	 */
	@Test
	public void TestNegateArray() {

	}
	
	@Test
	public void testLessThanThree() {
		assertTrue(this.alg.isLessThanThree(2));
	}
}
